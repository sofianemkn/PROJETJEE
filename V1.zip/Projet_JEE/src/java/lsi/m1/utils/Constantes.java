/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lsi.m1.utils;


public class Constantes {

    public static final String URL = "jdbc:derby://localhost:1527/JEEPRJ";
    public static final String USER_BDD = "jee";
    public static final String MDP_BDD = "jee";
    
    public static final String REQ_TOUS_UTILISATEUR = "SELECT * from UTILISATEUR";
    public static final String REQ_TOUS_EMPLOYES = "SELECT * from EMPLOYES";
    public static final String REQ_EMPLOYEE_BY_ID = "SELECT * from EMPLOYES WHERE ID = {0}";
    public static final String REQ_SUPP_EMPL = "DELETE FROM EMPLOYES WHERE ID = ";
    public static final String REQ_AJOUTER_EMPL = "INSERT INTO EMPLOYES (NOM,PRENOM,TELDOM,TELPORT,TELPRO,ADRESSE,CODEPOSTAL,VILLE,EMAIL) VALUES (?,?,?,?,?,?,?,?,?)";
    public static final String ERR_CONNEXION_KO = "Echec de la connexion ! Vérifiez votre login et/ou votre mot de passe et essayez à nouveau";
    public static final String ERR_CHAMP_VIDE = "Vous devez renseigner les deux champs";
    public static final String MSG_NO_EMPLOYES = "<span style='color:blue'>Nous devons recruter !</span>";
    public static final String MSG_SUPP_EMPL = "<span style='color:green'>Suppression réussie !</span>";
    public static final String ERR_SELECT_EMPL_SUPP = "<span style='color:red'>Veuillez sélectionner l'employé(e) à supprimer</span>";
    public static final String ERR_SELECT_EMPL = "Veuillez sélectionner un employé(e)";
    public static final String ERR_AJOUT_EMPL = "Echec de l'ajout.";
    public static final String IS_ADMIN_KEY = "admin";
    public static final String DETAILS_KEY = "true";
    
    public static final String FRM_LOGIN = "loginForm";
    public static final String FRM_MDP = "mdpForm";
    public static final String FRM_ID = "idForm";
    public static final String FRM_NOM = "nomForm";
    public static final String FRM_PRENOM = "prenomForm";
    public static final String FRM_TELDOM = "telDomForm";
    public static final String FRM_TELMOB = "telMobForm";
    public static final String FRM_TELPRO = "telProForm";
    public static final String FRM_ADRESSE = "adresseForm";
    public static final String FRM_CODE_POSTAL = "codePostalForm";
    public static final String FRM_VILLE = "villeForm";
    public static final String FRM_EMAIL = "emailForm";
    public static final String FRM_BTN_SUPP = "boutonSupp";
    public static final String FRM_BTN_AJOUTER = "boutonAjouter";
    public static final String FRM_BTN_DECO = "boutonDeco";
    public static final String FRM_BTN_VALIDER_FORM = "boutonValider";
    public static final String FRM_BTN_DETAILS = "boutonDetails";
    public static final String FRM_BTN_MODIFIER = "boutonModifier";
    public static final String FRM_BTN_VOIR_LISTE = "boutonVoirListe";
    
    public static final String JSP_ACCUEIL = "WEB-INF/accueil.jsp";
    public static final String JSP_BIENVENUE = "WEB-INF/bienvenue.jsp";
    public static final String JSP_DETAILS = "WEB-INF/details.jsp";
    
}
