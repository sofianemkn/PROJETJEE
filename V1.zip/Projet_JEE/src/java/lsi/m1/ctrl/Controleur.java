/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lsi.m1.ctrl;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import lsi.m1.model.ActionsBD;
import lsi.m1.model.EmployeBean;
import lsi.m1.model.Utilisateur;
import static lsi.m1.utils.Constantes.*;

public class Controleur extends HttpServlet {

    Utilisateur userInput;
    HttpSession session;
    ActionsBD actionsBD;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        actionsBD = new ActionsBD();

        //Clic bouton détails
        if (request.getParameter(FRM_BTN_DETAILS) != null) {
            String id = request.getParameter("radiobtn");
            if (id != null) {
                request.setAttribute("detailsKey", DETAILS_KEY);
                request.setAttribute("employee", actionsBD.getEmployeeById(id));
                request.getRequestDispatcher(JSP_DETAILS).forward(request, response);
            } else {
                request.setAttribute("errSelectEmpl", ERR_SELECT_EMPL);
                request.setAttribute("listeEmplKey", actionsBD.getEmployes());
                request.getRequestDispatcher(JSP_BIENVENUE).forward(request, response);
            }
        }

        //Clic bouton supprimer
        if (request.getParameter(FRM_BTN_SUPP) != null) {
            String id = request.getParameter("radiobtn");
            if (id != null) {
                actionsBD.supprimerEmpl(id);
                request.setAttribute("errSelectEmpl", MSG_SUPP_EMPL);
                request.setAttribute("listeEmplKey", actionsBD.getEmployes());
                request.getRequestDispatcher(JSP_BIENVENUE).forward(request, response);
            } else {
                request.setAttribute("errSelectEmpl", ERR_SELECT_EMPL_SUPP);
                request.setAttribute("listeEmplKey", actionsBD.getEmployes());
                request.getRequestDispatcher(JSP_BIENVENUE).forward(request, response);
            }
        }

        //clic bouton voir liste
        if (request.getParameter(FRM_BTN_VOIR_LISTE) != null) {
            request.setAttribute("listeEmplKey", actionsBD.getEmployes());
            request.getRequestDispatcher(JSP_BIENVENUE).forward(request, response);
        }

        //clic bouton modifier 
        if (request.getParameter(FRM_BTN_MODIFIER) != null) {
            EmployeBean empl = new EmployeBean();
            empl.setId(Integer.parseInt(request.getParameter(FRM_ID)));
            empl.setNom(request.getParameter(FRM_NOM));
            empl.setPrenom(request.getParameter(FRM_PRENOM));
            empl.setTelDom(request.getParameter(FRM_TELDOM));
            empl.setTelPort(request.getParameter(FRM_TELMOB));
            empl.setTelPro(request.getParameter(FRM_TELPRO));
            empl.setAdresse(request.getParameter(FRM_ADRESSE));
            empl.setCodePostal(request.getParameter(FRM_CODE_POSTAL));
            empl.setVille(request.getParameter(FRM_VILLE));
            empl.setEmail(request.getParameter(FRM_EMAIL));

            actionsBD.modifierEmpl(empl);
            request.setAttribute("listeEmplKey", actionsBD.getEmployes());
            request.getRequestDispatcher(JSP_BIENVENUE).forward(request, response);
        }

        //clic bouton ajouter
        if (request.getParameter(FRM_BTN_AJOUTER) != null) {
            request.getRequestDispatcher(JSP_DETAILS).forward(request, response);
        }
        
        //clic bouton déconnexion
        if (request.getParameter(FRM_BTN_DECO) != null){
            session.removeAttribute("adminKey");
            request.getRequestDispatcher(JSP_ACCUEIL).forward(request, response);
        }

        //clic bouton valider formulaire ajout
        if (request.getParameter(FRM_BTN_VALIDER_FORM) != null) {
            EmployeBean empl = new EmployeBean();
            empl.setNom(request.getParameter(FRM_NOM));
            empl.setPrenom(request.getParameter(FRM_PRENOM));
            empl.setTelDom(request.getParameter(FRM_TELDOM));
            empl.setTelPort(request.getParameter(FRM_TELMOB));
            empl.setTelPro(request.getParameter(FRM_TELPRO));
            empl.setAdresse(request.getParameter(FRM_ADRESSE));
            empl.setCodePostal(request.getParameter(FRM_CODE_POSTAL));
            empl.setVille(request.getParameter(FRM_VILLE));
            empl.setEmail(request.getParameter(FRM_EMAIL));

            actionsBD.ajouterEmpl(empl);
            request.setAttribute("listeEmplKey", actionsBD.getEmployes());
            request.getRequestDispatcher(JSP_BIENVENUE).forward(request, response);
        }

        //premier lancement du projet...
        if (request.getParameter(FRM_LOGIN) == null) {
            request.getRequestDispatcher(JSP_ACCUEIL).forward(request, response);
        } else if (request.getParameter(FRM_LOGIN) == "" || request.getParameter(FRM_MDP) == "") {
            request.setAttribute("errKey", ERR_CHAMP_VIDE);
            request.setAttribute("listeEmplKey", actionsBD.getEmployes());
            request.getRequestDispatcher(JSP_ACCUEIL).forward(request, response);
        } else {
            //Accéder à la page Bienvenue...
            session = request.getSession();
            userInput = new Utilisateur();

            userInput.setLogin(request.getParameter(FRM_LOGIN));
            userInput.setMdp(request.getParameter(FRM_MDP));

            request.setAttribute("userBean", userInput);

            if (actionsBD.verifInfosConnexion(userInput)) {

                if (actionsBD.estAdmin(userInput)) {
                    //administrateur
                    if (actionsBD.getEmployes().isEmpty()) {
                        request.setAttribute("noEmployesKey", MSG_NO_EMPLOYES);
                        request.getRequestDispatcher(JSP_BIENVENUE).forward(request, response);
                    } else {
                        session.setAttribute("adminKey", IS_ADMIN_KEY);
                        request.setAttribute("listeEmplKey", actionsBD.getEmployes());
                        request.getRequestDispatcher(JSP_BIENVENUE).forward(request, response);
                    }
                } else //employé
                if (actionsBD.getEmployes().isEmpty()) {
                    request.setAttribute("noEmployesKey", MSG_NO_EMPLOYES);
                    request.getRequestDispatcher(JSP_BIENVENUE).forward(request, response);
                } else {
                    session.removeAttribute("adminKey");
                    request.setAttribute("listeEmplKey", actionsBD.getEmployes());
                    request.getRequestDispatcher(JSP_BIENVENUE).forward(request, response);
                }

            } else {
                request.setAttribute("errKey", ERR_CONNEXION_KO);
                request.getRequestDispatcher(JSP_ACCUEIL).forward(request, response);
            }

        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
