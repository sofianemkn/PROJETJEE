/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lsi.m1.model;

/**
 *
 * @author Sofiane/Mouloud/Moise
 */
public class EmployeBean {
    private int id;
    private String nom;
    private String prenom;
    private String telDom;
    private String telPort;
    private String telPro;
    private String adresse;
    private String codePostal;
    private String ville;
    private String email;

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }
    
    /**
     *
     * @return
     */
    public String getNom() {
        return nom;
    }

    /**
     *
     * @param nom
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     *
     * @return
     */
    public String getPrenom() {
        return prenom;
    }

    /**
     *
     * @param prenom
     */
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    /**
     *
     * @return
     */
    public String getTelDom() {
        return telDom;
    }

    /**
     *
     * @param telDom
     */
    public void setTelDom(String telDom) {
        this.telDom = telDom;
    }

    /**
     *
     * @return
     */
    public String getTelPort() {
        return telPort;
    }

    /**
     *
     * @param telPort
     */
    public void setTelPort(String telPort) {
        this.telPort = telPort;
    }

    /**
     *
     * @return
     */
    public String getTelPro() {
        return telPro;
    }

    /**
     *
     * @param telPro
     */
    public void setTelPro(String telPro) {
        this.telPro = telPro;
    }

    /**
     *
     * @return
     */
    public String getAdresse() {
        return adresse;
    }

    /**
     *
     * @param adresse
     */
    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    /**
     *
     * @return
     */
    public String getCodePostal() {
        return codePostal;
    }

    /**
     *
     * @param codePostal
     */
    public void setCodePostal(String codePostal) {
        this.codePostal = codePostal;
    }

    /**
     *
     * @return
     */
    public String getVille() {
        return ville;
    }

    /**
     *
     * @param ville
     */
    public void setVille(String ville) {
        this.ville = ville;
    }

    /**
     *
     * @return
     */
    public String getEmail() {
        return email;
    }

    /**
     *
     * @param email
     */
    public void setEmail(String email) {
        this.email = email;
    }    
}
