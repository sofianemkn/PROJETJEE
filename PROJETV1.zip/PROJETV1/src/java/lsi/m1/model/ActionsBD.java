package lsi.m1.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import static lsi.m1.utils.Constantes.*;

/**
 *
 * @author Sofiane/Mouloud/Moise
 */
public class ActionsBD {

    Connection conn;
    Statement stmt;
    ResultSet rs;
    Utilisateur user;
    ArrayList<Utilisateur> userList;
    HashMap<String, EmployeBean> empList;

    /**
     *
     */
    public ActionsBD() {
        try {
            conn = DriverManager.getConnection(URL, LOGIN_BDD, PWD_BDD);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    /**
     *
     * @return
     */
    public Statement getStatement() {
        try {
            stmt = conn.createStatement();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return stmt;
    }

    /**
     *
     * @param req
     * @return
     */
    public ResultSet getResultSet(String req) {
        try {
            stmt = getStatement();

            rs = stmt.executeQuery(req);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return rs;
    }

    /**
     *
     * @return
     */
    public ArrayList getUtilisateurs() {
        userList = new ArrayList<>();
        try {
            rs = getResultSet(REQ_ALL_USERS);

            while (rs.next()) {
                Utilisateur userBean = new Utilisateur();
                userBean.setLogin(rs.getString("LOGIN"));
                userBean.setMdp(rs.getString("PASSWORD"));
                userBean.setIsAdmin(rs.getBoolean("IS_ADMIN"));
                

                userList.add(userBean);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return userList;
    }
    
    /**
     *
     * @param id
     * @return
     */
    public EmployeBean getEmployeeById(String id){
        empList = getEmployes();
        return empList.get(id);
    }
     
    /**
     *
     * @return
     */
    public HashMap<String, EmployeBean> getEmployes() {
        empList = new HashMap<>();
        try {
            rs = getResultSet(REQ_ALL_EMP);

            while (rs.next()) {
                EmployeBean emplBean = new EmployeBean();
                emplBean.setId(rs.getInt("ID"));
                emplBean.setNom(rs.getString("NOM"));
                emplBean.setPrenom(rs.getString("PRENOM"));
                emplBean.setTelDom(rs.getString("TELDOM"));
                emplBean.setTelPort(rs.getString("TELPORT"));
                emplBean.setTelPro(rs.getString("TELPRO"));
                emplBean.setAdresse(rs.getString("ADRESSE"));
                emplBean.setCodePostal(rs.getString("CODEPOSTAL"));
                emplBean.setVille(rs.getString("VILLE"));
                emplBean.setEmail(rs.getString("EMAIL"));

                empList.put(emplBean.getId()+"",emplBean);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return empList;
    }

    /**
     *
     * @param userInput
     * @return
     */
    public boolean verifInfosConnexion(Utilisateur userInput) {
        boolean test = false;

        userList = getUtilisateurs();

        for (Utilisateur userBase : userList) {
            if (userBase.getLogin().equals(userInput.getLogin())
                    && userBase.getMdp().equals(userInput.getMdp())) {
                userInput.setIsAdmin(userBase.isAdmin());
                test = true;
            }
        }

        return test;
    }
    
    /**
     *
     * @param userInput
     * @return
     */
    public boolean estAdmin(Utilisateur userInput){
        
        return userInput.isAdmin();
    }

    /**
     *
     * @param request
     * @param args
     * @return
     */
    public String requestAssembler(String request, String... args){
        String newString = request;
        for(int i = 0; i<args.length; i++){
            newString = newString.replace("{"+i+"}", args[i]);
        }
        return newString;
    }
    
    /**
     *
     * @param id
     * @return
     */
    public String getEqId(String id){
        int i = Integer.parseInt(id);
        i = i-1;
        return i + "";
    }
    
    /**
     *
     * @param id
     */
    public void supprimerEmpl(String id){
        try {
            stmt = getStatement();
            stmt.executeUpdate(REQ_DEL_EMPL + id);
        } catch (SQLException ex) {
            Logger.getLogger(ActionsBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     *
     * @param empl
     */
    public void modifierEmpl(EmployeBean empl){
        stmt = getStatement();
        try {
            stmt.executeUpdate("UPDATE EMPLOYES SET NOM = '"
                    + empl.getNom() + "',"
                    + "PRENOM = '" + empl.getPrenom() + "',"
                    + "TELDOM = '" + empl.getTelDom() + "',"
                    + "TELPORT = '" + empl.getTelPort() + "',"
                    + "TELPRO = '" + empl.getTelPro() + "',"
                    + "ADRESSE = '" + empl.getAdresse() + "',"
                    + "CODEPOSTAL = '" + empl.getCodePostal() + "',"
                    + "VILLE = '" + empl.getVille() + "',"
                    + "EMAIL = '" + empl.getEmail() + "'"
                    + "WHERE ID = " + empl.getId()
            );
        } catch (SQLException ex) {
            Logger.getLogger(ActionsBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     *
     * @param empl
     */
    public void ajouterEmpl(EmployeBean empl){
        String nom = empl.getNom();
        String prenom = empl.getPrenom();
        String teldom = empl.getTelDom();
        String telport = empl.getTelPort();
        String telpro = empl.getTelPro();
        String adresse = empl.getAdresse();
        String codepostal = empl.getCodePostal();
        String ville = empl.getVille();
        String email = empl.getEmail();
        try {
            PreparedStatement pstmt =  conn.prepareStatement(REQ_AJOUTER_EMPL);
            pstmt.setString(1, nom);
            pstmt.setString(2, prenom);
            pstmt.setString(3, teldom);
            pstmt.setString(4, telport);
            pstmt.setString(5, telpro);
            pstmt.setString(6, adresse);
            pstmt.setString(7, codepostal);
            pstmt.setString(8, ville);
            pstmt.setString(9, email);
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ActionsBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}