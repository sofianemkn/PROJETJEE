/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lsi.m1.utils;

/**
 *
 * @author Sofiane/Mouloud/Moise
 */
public class Constantes {

    /**
     *
     */
    public static final String URL = "jdbc:derby://localhost:1527/JEEPRJ";

    /**
     *
     */
    public static final String LOGIN_BDD = "jee";

    /**
     *
     */
    public static final String PWD_BDD = "jee";
    
    /**
     *
     */
    public static final String REQ_ALL_USERS = "SELECT * from UTILISATEUR";

    /**
     *
     */
    public static final String REQ_ALL_EMP = "SELECT * from EMPLOYES";

    /**
     *
     */
    public static final String REQ_AJOUTER_EMPL = "INSERT INTO EMPLOYES (NOM,PRENOM,TELDOM,TELPORT,TELPRO,ADRESSE,CODEPOSTAL,VILLE,EMAIL) VALUES (?,?,?,?,?,?,?,?,?)";

    /**
     *
     */
    public static final String REQ_EMPLOYEE_BY_ID = "SELECT * from EMPLOYES WHERE ID = {0}";

    /**
     *
     */
    public static final String REQ_DEL_EMPL = "DELETE FROM EMPLOYES WHERE ID = ";
    
    /**
     *
     */
    public static final String ERR_EMPTY_FIELD = "Renseigner login ET mot de passe";

    /**
     *
     */
    public static final String ERR_SEL_EMP = "Selectionner un employé";

    /**
     *
     */
    public static final String ERR_SEL_DEL_EMP = "<span style='color:#FF0000'>Selectionner l'employé à supprimer</span>";

    /**
     *
     */
    public static final String ERR_CONNECTION = "Erreur de connexion ! Revérifiez votre login et votre mot de passe avant de réessayer.";
    
    /**
     *
     */
    public static final String MSG_NO_EMPLOYES = "<span style='color:blue'>Nous devons recruter !</span>";

    /**
     *
     */
    public static final String MSG_SUPP_EMPL = "<span style='color:green'>Suppression réussie !</span>";
    
    /**
     *
     */
    public static final String WRNG_NO_EMP = "<span style='color:#0000FF'>Aucun employé !</span>";

    /**
     *
     */
    public static final String WRNG_EMP_DEL = "<span style='color:#008000'>Suppression effectuée !</span>";
    
    /**
     *
     */
    public static final String IS_ADMIN = "admin";

    /**
     *
     */
    public static final String TRUE_KEY = "true";
    
    /**
     *
     */
    public static final String LOGIN = "loginForm";

    /**
     *
     */
    public static final String MDP = "mdpForm";

    /**
     *
     */
    public static final String ID = "idForm";

    /**
     *
     */
    public static final String NOM = "nomForm";

    /**
     *
     */
    public static final String PRENOM = "prenomForm";

    /**
     *
     */
    public static final String TELDOM = "telDomForm";

    /**
     *
     */
    public static final String TELMOB = "telMobForm";

    /**
     *
     */
    public static final String TELPRO = "telProForm";

    /**
     *
     */
    public static final String ADRESSE = "adresseForm";

    /**
     *
     */
    public static final String CODE_POSTAL = "codePostalForm";

    /**
     *
     */
    public static final String VILLE = "villeForm";

    /**
     *
     */
    public static final String EMAIL = "emailForm";

    /**
     *
     */
    public static final String BTN_DEL = "boutonSupp";

    /**
     *
     */
    public static final String BTN_ADD = "boutonAjouter";

    /**
     *
     */
    public static final String BTN_LOGOUT = "boutonDeco";

    /**
     *
     */
    public static final String BTN_VALID_FORM = "boutonValider";

    /**
     *
     */
    public static final String BTN_DETAILS = "boutonDetails";

    /**
     *
     */
    public static final String BTN_MODIFY = "boutonModifier";

    /**
     *
     */
    public static final String BTN_LIST = "boutonVoirListe";
    
    /**
     *
     */
    public static final String ACCUEIL = "WEB-INF/accueil.jsp";

    /**
     *
     */
    public static final String BIENVENUE = "WEB-INF/bienvenue.jsp";

    /**
     *
     */
    public static final String CREATE = "WEB-INF/createForm.jsp";

    /**
     *
     */
    public static final String DETAILS = "WEB-INF/details.jsp";
    
}
