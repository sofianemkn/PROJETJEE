/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lsi.m1.model;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import javax.persistence.Query;

/**
 *
 * @author Sofiane
 */
@Stateless
public class UtilisateurSB {

    @PersistenceContext
    EntityManager em;
    
    ArrayList<Utilisateur> listU;
    Utilisateur returnU;
    
    /**
     * 
     * @return 
     */
     public ArrayList<Utilisateur> getU(){
        listU = new ArrayList<>();
        Query q = em.createNamedQuery("Utilisateur.findAll");
        listU.addAll(q.getResultList());
        return listU;
    }
     
     /**
      * 
      * @param input
      * @return 
      */
     public Utilisateur checkConnexion(Utilisateur input)
   {
      
       listU=getU();
       returnU= null;
     
       
       for(int i=0 ; i<listU.size();i++)
       {
           if(listU.get(i).getLogin().equals(input.getLogin()) && listU.get(i).getPassword().equals(input.getPassword()))
               
           {  input.setIsAdmin(listU.get(i).getIsAdmin());
              returnU = listU.get(i);
           }
           
       }
      return returnU;     
   }
    
}
