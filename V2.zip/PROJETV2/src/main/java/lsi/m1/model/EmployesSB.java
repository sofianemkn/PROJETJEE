/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lsi.m1.model;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import javax.persistence.Query;

/**
 *
 * @author Sofiane
 */
@Stateless
public class EmployesSB {
    @PersistenceContext
    EntityManager em;
    
    ArrayList<Employes> liste;
    /**
     * 
     * @return 
     */
    public ArrayList<Employes> getEmployes(){
        liste = new ArrayList<>();
        Query q = em.createNamedQuery("Employes.findAll");
        liste.addAll(q.getResultList());
        return liste;
    }
    /**
     * 
     * @param id
     * @return 
     */
    public Employes getEmployesByID(String id){
        
            Query q = em.createNamedQuery("Employes.findById");
            q.setParameter("id", Integer.parseInt(id));
            return (Employes) q.getSingleResult();
    }
    /**
     * 
     * @param id 
     */
    public void deleteEmployesByID(String id){
        Query q = em.createNamedQuery("Employes.deleteById");
        q.setParameter("id", Integer.parseInt(id));
        q.executeUpdate();
    }
    /**
     * 
     * @param e 
     */
    public void addEmployee(Employes e){
        em.persist(e);
    }
    /**
     * 
     * @param e 
     */
    public void updateEmployee(Employes e){
        em.merge(e);
    }
}
