 /* To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lsi.m1.ctrl;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import lsi.m1.model.Employes;
import lsi.m1.model.EmployesSB;
import lsi.m1.model.Utilisateur;
import lsi.m1.model.UtilisateurSB;
import static lsi.m1.utils.Constantes.*;

public class Controleur extends HttpServlet {
    
    @EJB
    private EmployesSB employeSB;
    
    @EJB
    private UtilisateurSB userSB;
    
    Utilisateur userInput;
    Employes employeSelected;
    
    HttpSession session;
    
    /**
     * 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException 
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //actionsBD = new ActionsBD();

        //Clic bouton détails
        if (request.getParameter(BTN_DETAILS) != null) {
            String id = request.getParameter("radiobtn");
            if (id != null) {
                request.setAttribute("detailsKey", TRUE_KEY);
                request.setAttribute("employee", employeSB.getEmployesByID(id));
                request.getRequestDispatcher(DETAILS).forward(request, response);
            } else {
                request.setAttribute("errEmpSelected", ERR_SEL_EMP);
                request.setAttribute("EmpList", employeSB.getEmployes());
                request.getRequestDispatcher(BIENVENUE).forward(request, response);
            }
        }

        //Clic bouton supprimer
        if (request.getParameter(BTN_DEL) != null) {
            String id = request.getParameter("radiobtn");
            if (id != null) {
                employeSB.deleteEmployesByID(id);
                request.setAttribute("errEmpSelected", WRNG_EMP_DEL);
                request.setAttribute("EmpList", employeSB.getEmployes());
                request.getRequestDispatcher(BIENVENUE).forward(request, response);
            } else {
                request.setAttribute("errEmpSelected", ERR_SEL_DEL_EMP);
                request.setAttribute("EmpList", employeSB.getEmployes());
                request.getRequestDispatcher(BIENVENUE).forward(request, response);
            }
        }

        //clic bouton voir liste
        if (request.getParameter(BTN_LIST) != null) {
            request.setAttribute("EmpList", employeSB.getEmployes());
            request.getRequestDispatcher(BIENVENUE).forward(request, response);
        }

        //clic bouton modifier 
        if (request.getParameter(BTN_MODIFY) != null) {
            Employes empl = new Employes();
            empl.setId(Integer.parseInt(request.getParameter(ID)));
            empl.setNom(request.getParameter(NOM));
            empl.setPrenom(request.getParameter(PRENOM));
            empl.setTeldom(request.getParameter(TELDOM));
            empl.setTelport(request.getParameter(TELMOB));
            empl.setTelpro(request.getParameter(TELPRO));
            empl.setAdresse(request.getParameter(ADRESSE));
            empl.setCodepostal(request.getParameter(CODE_POSTAL));
            empl.setVille(request.getParameter(VILLE));
            empl.setEmail(request.getParameter(EMAIL));

            employeSB.updateEmployee(empl);
            request.setAttribute("EmpList", employeSB.getEmployes());
            request.getRequestDispatcher(BIENVENUE).forward(request, response);
        }

        //clic bouton ajouter
        if (request.getParameter(BTN_ADD) != null) {
            request.getRequestDispatcher(DETAILS).forward(request, response);
        }
        
        //clic bouton déconnexion
        if (request.getParameter(BTN_LOGOUT) != null){
            session.removeAttribute("adminKey");
            request.getRequestDispatcher(ACCUEIL).forward(request, response);
        }

        //clic bouton valider formulaire ajout
        if (request.getParameter(BTN_VALID_FORM) != null) {
            Employes empl = new Employes();
            empl.setNom(request.getParameter(NOM));
            empl.setPrenom(request.getParameter(PRENOM));
            empl.setTeldom(request.getParameter(TELDOM));
            empl.setTelport(request.getParameter(TELMOB));
            empl.setTelpro(request.getParameter(TELPRO));
            empl.setAdresse(request.getParameter(ADRESSE));
            empl.setCodepostal(request.getParameter(CODE_POSTAL));
            empl.setVille(request.getParameter(VILLE));
            empl.setEmail(request.getParameter(EMAIL));

            employeSB.addEmployee(empl);
            request.setAttribute("EmpList", employeSB.getEmployes());
            request.getRequestDispatcher(BIENVENUE).forward(request, response);
        }

        //premier lancement du projet...
        if (request.getParameter(LOGIN) == null) {
            request.getRequestDispatcher(ACCUEIL).forward(request, response);
        } else if (request.getParameter(LOGIN) == "" || request.getParameter(MDP) == "") {
            request.setAttribute("errKey", ERR_EMPTY_FIELD);
            request.setAttribute("EmpList", employeSB.getEmployes());
            request.getRequestDispatcher(ACCUEIL).forward(request, response);
        } else {
            //Accéder à la page Bienvenue...
            session = request.getSession();
            userInput = new Utilisateur();

            userInput.setLogin(request.getParameter(LOGIN));
            userInput.setPassword(request.getParameter(MDP));

            request.setAttribute("userBean", userInput);

            if (userSB.checkConnexion(userInput)!= null) {
                if (userInput.getIsAdmin()) {
                    //administrateur
                    if (employeSB.getEmployes().isEmpty()) {
                        request.setAttribute("noEmployesKey", WRNG_NO_EMP);
                        request.getRequestDispatcher(BIENVENUE).forward(request, response);
                    } else {
                        session.setAttribute("adminKey", IS_ADMIN);
                        request.setAttribute("EmpList", employeSB.getEmployes());
                        request.getRequestDispatcher(BIENVENUE).forward(request, response);
                    }
                } else //employé
                if (employeSB.getEmployes().isEmpty()) {
                    request.setAttribute("noEmployesKey", WRNG_NO_EMP);
                    request.getRequestDispatcher(BIENVENUE).forward(request, response);
                } else {
                    session.removeAttribute("adminKey");
                    request.setAttribute("EmpList", employeSB.getEmployes());
                    request.getRequestDispatcher(BIENVENUE).forward(request, response);
                }

            } else {
                request.setAttribute("errKey", ERR_CONNECTION);
                request.getRequestDispatcher(ACCUEIL).forward(request, response);
            }

        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
